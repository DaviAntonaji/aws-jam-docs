#!/bin/bash
yum update -y
yum install jq netcat -y
amazon-linux-extras install nginx1 -y

